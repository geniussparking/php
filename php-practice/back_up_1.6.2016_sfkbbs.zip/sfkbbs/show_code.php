<?php 
session_start();
include_once 'inc/vcode.inc.php';
$_SESSION['vcode']=vcode(100,40,30,4); //将验证码函数返回的字符串保存到一个SESSION里面
?>