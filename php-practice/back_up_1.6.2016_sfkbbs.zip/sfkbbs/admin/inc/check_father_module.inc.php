<?php 
if(empty($_POST['module_name']) || mb_strlen($_POST['module_name'],'utf8')>66){   //empty($_POST['sort']) 这里最好不要加empty这个判断，会导致sort填0时不能通过，因为0也会被认为是空
	skip('father_module_add.php', 'error', '版块名不得为空,或不能多于66个字符!');
}
if(!is_numeric($_POST['sort'])){
	skip('father_module_add.php', 'error', '排序必须为数字！');
}
$_POST=escape($link, $_POST); //过滤数据，转义特殊字符
switch ($check_flag){
	case 'add':
		$query="select * from sfk_father_module where module_name='{$_POST['module_name']}'";
		break;
	case 'update':
		$query="select * from sfk_father_module where module_name='{$_POST['module_name']}' && id!={$_GET['id']}";   //这里的条件限制太难想到了
		break;
	default:
		skip('father_module.php', 'error', '$check_flag参数错误！');
}
$result=execute($link, $query);
if(mysqli_num_rows($result)){   //这里写成mysqli_affected_rows($link)也是一样
	skip('father_module.php', 'error', '版块已经存在！');
}
?>