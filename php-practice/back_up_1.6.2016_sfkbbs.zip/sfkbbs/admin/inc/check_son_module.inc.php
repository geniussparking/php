<?php 
if(!is_numeric($_POST['father_module_id'])){
	skip('soon_module_add.php', 'error', '所属父版块不得为空！');
}
$query="select * from sfk_father_module where id={$_POST['father_module_id']}";
$result=execute($link, $query);
if(mysqli_num_rows($result)==0){
	skip('son_module_add.php', 'error', '所属父版块不存在！');
}
if(empty($_POST['module_name']) || mb_strlen($_POST['module_name'],'utf8')>66){  
	skip('son_module_add.php', 'error', '子版块名不得为空,或不能多于66个字符!');
}
$_POST=escape($link, $_POST);
switch ($check_flag){
	case 'add':
		$query="select * from sfk_son_module where module_name='{$_POST['module_name']}'";
		break;
	case 'update':
		$query="select * from sfk_son_module where module_name='{$_POST['module_name']}' && id!={$_GET['id']}";
		break;
	default:
		skip('son_module.php', 'error', '$check_flag参数错误！');
}
$result=execute($link, $query);
if(mysqli_num_rows($result)){   //这里写成mysqli_affected_rows($link)也是一样
	skip('son_module_add.php', 'error', '子版块已经存在！');
}
if(mb_strlen($_POST['info'],'utf8')>255){   
	skip('son_module_add.php', 'error', '子版块简介不得多于255个字符!');
}
if(!is_numeric($_POST['sort'])){
	skip('son_module_add.php', 'error', '排序必须为数字！');
}
?>