<?php 
include_once '../inc/config.inc.php';
include_once '../inc/mysql.inc.php';
include_once '../inc/tool.inc.php';
if(!isset($_GET['id']) || !is_numeric($_GET['id'])){    //判断get进来的id是否合法， is_numeric是判断id是不是数字型的字符串，以防止id=1 or 1=1会删除数据库里面所有数据
	skip('father_module.php','error','id参数传递失败！');
}
$link=connect();
$query="select * from sfk_son_module where father_module_id={$_GET['id']}";
$result=execute($link, $query);
if(mysqli_num_rows($result)){
	skip('father_module.php','error','该父版块下面存在子版块，请先将对应的子版块删掉！');
}
//var_dump($_GET);//输出get方式获取的数据
$query="delete from sfk_father_module where id={$_GET['id']}";
//echo $query;  //可以看具体的sql语句
execute($link, $query);
if(mysqli_affected_rows($link)==1){
	skip('father_module.php','ok','删除成功！'); //传值到skip这个函数去
 }else{
 	skip('father_module.php','error','删除失败，请重试！');
 }
?>