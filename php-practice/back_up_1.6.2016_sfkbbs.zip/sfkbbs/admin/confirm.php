<?php 
include_once '../inc/config.inc.php';
//var_dump($_GET['return_url']);  //所有以get方式获取的数据都以数组形式存在$_GET这个变量里面
//var_dump($_SERVER); //$_SERVER里面保存的数据很强大，$_SERVER['HTTP_REFERER']这个里面保存的是上一个页的url地址
if(!isset($_GET['message']) || !isset($_GET['url']) || !isset($_GET['return_url'])){
	exit('非法操作！变量不存在，自动退出！');
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title>确认页</title>
<meta name="keywords" content="确认页" />
<meta name="description" content="确认页" />
<link rel="stylesheet" type="text/css" href="style/remind.css" />
</head>
<body>
<div class="notice"><span class="pic ask"></span> <?php echo $_GET['message']?> <a  href="<?php echo $_GET['url']?>" style="color:red;"> 确定</a> | <a href="<?php echo $_GET['return_url']?>" style="color:green;">取消</a> </div>
</body>
</html>