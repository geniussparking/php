<?php 
include_once '../inc/config.inc.php';
include_once '../inc/mysql.inc.php';
include_once '../inc/tool.inc.php';
//var_dump($_POST);exit();
//echo mb_strlen($_POST['module_name'],'utf-8'); //计算字符数
if(isset($_POST['submit'])){   //判断有没有点击“添加”按钮
	$link=connect();
	//验证用户填写的信息
	$check_flag='add';
	include 'inc/check_father_module.inc.php'; 	
	$query="insert into sfk_father_module(module_name,sort) values('{$_POST['module_name']}',{$_POST['sort']})";	
	execute($link, $query);
	if(mysqli_affected_rows($link)==1){
		skip('father_module.php', 'ok', '添加数据成功！');
	}else{
		skip('father_module_add.php', 'error', '添加数据失败！');
	}

}
$template['title']='添加父版块';
$template['keywords']='添加父版块';
$template['description']='添加父版块';
$template['style']=array('style/public.css','style/father_module_add.css'); //如果有多个css文件，这样可以将多个css文件引入（header文件里面）
?>
<?php include 'inc/header.inc.php'?>

<div id="main">
	<div class="title" style="margin-bottom:20px;">添加父版块</div>
		<form method="post">
			<table class="au">
				<tr>
					<td>版块名称</td>
					<td><input name="module_name" type="text" /></td>
					<td>
						版块名称不得为空，最大不得超过66个字符
					</td>
				</tr>
				<tr>
					<td>排序</td>
					<td><input name="sort" value="0" type="text" /></td>
					<td>
						填写数字
					</td>
				</tr>
			</table>
			<input style="margin-top:20px; cursor:pointer;" class="btn" type="submit" name="submit" value="添加" />
		</form>
</div>
<?php include 'inc/footer.inc.php'?>