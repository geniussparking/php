<?php 
function skip($url,$pic,$message){  //注意调用这个函数的时候，传过来的值，下面是怎么用的
$html=<<<A
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta http-equiv="refresh" content="3;URL={$url}" />
<title>正在跳转中</title>
<link rel="stylesheet" type="text/css" href="style/remind.css" />
</head>
<body>
<div class="notice"><span class="pic {$pic}"></span> {$message}<a href="{$url}">3秒后自动跳转！</a></div>
</body>
</html>
A;
echo $html;
exit;
}
function is_login($link){
	if(isset($_COOKIE['sfk']['name']) && isset($_COOKIE['sfk']['pw'])){
		$query="select * from sfk_member where name='{$_COOKIE['sfk']['name']}' and sha1(pw)='{$_COOKIE['sfk']['pw']}'";  //因为涉及到将密码存进cookie，密码被双重加密了，在存入数据库的时候只用了md5加密，那这里就要加一个sha1加密
		$result=execute($link, $query);
		if(mysqli_num_rows($result)==1){
			$data=mysqli_fetch_assoc($result);
			return $data['id'];  //返回会员的ID号，登录成功
		}else{
			return false;
		}
	}else{
		return false;
	}
}
?>